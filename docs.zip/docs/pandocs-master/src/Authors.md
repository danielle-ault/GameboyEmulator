# Acknowledgements

The maintenance and expansion of this project wouldn't be possible without the continued commitment and support of:

- The [gbdev community](https://gbdev.io), for providing precious feedback, content, support and invaluable knowledge.
- [Contributors](https://github.com/gbdev/pandocs/graphs/contributors) of code and content on the Pan Docs project.
- [DigitalOcean](https://www.digitalocean.com/), for sponsoring this initiative and lifting us from any hosting and infrastructural cost in the last few years.
- [Backers](https://opencollective.com/gbdev), for allowing us to push the community projects further and spread open culture while staying independent and free.

## Authors

Antonio Niño Díaz, Antonio Vivace, Beannaich, Cory Sandlin, Eldred "ISSOtm" Habert, Elizafox, Furrtek, Gekkio, Jeff Frohwein, John Harrison, Lior "LIJI32" Halphon, Mantidactyle, Marat Fayzullin, Martin "nocash" Korth, Pan of ATX, Pascal Felber, Paul Robson, T4g1, TechFalcon, endrift, exezin, jrra, kOOPa, mattcurrie, nitro2k01, pinobatch, Pat Fagan, Alvaro Burnett.

## Special thanks

FrankenGraphics, zeta0134.
