<small>This section was originally compiled by Shonumi in the "Dan Docs". Upstream source can be found <a href="https://shonumi.github.io/dandocs.html" target="_blank">here</a>.</small>
